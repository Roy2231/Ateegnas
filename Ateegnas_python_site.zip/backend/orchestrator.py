import os
import asyncio
from backend.agents.preprocess_agent import preprocess_text
from backend.agents.annotate_agent import annotate_batch_async
from backend.agents.validate_agent import validate_batch
from backend.utils.finops import FinOpsManager
from backend.utils.mcp import choose_model_for_batch
from backend.db import database, results

finops = FinOpsManager()

async def orchestrate_dataset(lines, batch_size=100, user_id=None):
    # chunk into batches
    batches = [lines[i:i+batch_size] for i in range(0, len(lines), batch_size)]
    for batch in batches:
        # preprocess
        preprocessed = [preprocess_text(t) for t in batch]
        # decide model
        model = choose_model_for_batch(preprocessed)
        # annotate (async call to modal or remote)
        annotations = await annotate_batch_async(preprocessed, model=model)
        # validate
        validations = validate_batch(preprocessed, annotations)
        # store results and log finops
        for txt, ann, val in zip(batch, annotations, validations):
            await database.execute(results.insert().values(user_id=user_id, text=txt, label=ann, model=model))
            finops.log_cost(model, tokens=len(txt.split())*4)
    return True

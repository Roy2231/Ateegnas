import spacy, os
nlp = None
try:
    nlp = spacy.load('en_core_web_sm')
except Exception:
    # graceful fallback to blank if model not downloaded
    from spacy.lang.en import English
    nlp = English()

def preprocess_text(text: str) -> str:
    doc = nlp(text)
    tokens = [t.lemma_.lower() for t in doc if getattr(t, 'is_alpha', True) and not getattr(t, 'is_stop', False)]
    return ' '.join(tokens)

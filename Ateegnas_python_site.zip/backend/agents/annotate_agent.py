import os, httpx, asyncio, json
from backend.utils.mcp import get_openai_model_name

OPENAI_KEY = os.getenv('OPENAI_API_KEY')

async def call_openai_chat(model, prompt):
    url = 'https://api.openai.com/v1/chat/completions'
    headers = {'Authorization': f'Bearer {OPENAI_KEY}', 'Content-Type': 'application/json'}
    payload = {
        'model': model,
        'messages': [
            {'role': 'system', 'content': 'You are an annotation assistant.'},
            {'role': 'user', 'content': prompt}
        ],
        'temperature': 0.0,
        'max_tokens': 512
    }
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        return r.json()

async def annotate_batch_async(texts, model=None):
    # model param is the model name string
    if model is None:
        model = get_openai_model_name()
    prompts = [f"Annotate this: {t}" for t in texts]
    # send requests in parallel but limited concurrency
    semaphore = asyncio.Semaphore(10)
    async def sem_call(p):
        async with semaphore:
            resp = await call_openai_chat(model, p)
            return resp['choices'][0]['message']['content'].strip()
    tasks = [sem_call(p) for p in prompts]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    # normalize exceptions
    output = []
    for r in results:
        if isinstance(r, Exception):
            output.append('ERROR_ANNOTATION')
        else:
            output.append(r)
    return output

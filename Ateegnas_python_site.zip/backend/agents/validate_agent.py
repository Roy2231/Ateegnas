from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

tokenizer = AutoTokenizer.from_pretrained('distilbert-base-uncased')
model = AutoModelForSequenceClassification.from_pretrained('distilbert-base-uncased')

def validate_batch(texts, annotations):
    results = []
    for t, a in zip(texts, annotations):
        inputs = tokenizer(t, return_tensors='pt', truncation=True)
        with torch.no_grad():
            out = model(**inputs)
            probs = torch.nn.functional.softmax(out.logits, dim=-1)
            pred = torch.argmax(probs).item()
        # simple heuristic: check numeric label presence
        ok = 1 if str(pred) in a else 0
        results.append({'score': ok, 'pred': str(pred)})
    return results

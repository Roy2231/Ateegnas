import os
import asyncio
from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from dotenv import load_dotenv
from backend.db import database, metadata, engine, users, results, testimonials
from backend.auth import get_current_user, create_user, verify_user
from backend.orchestrator import orchestrate_dataset
from backend.utils.finops import FinOpsManager
from backend.utils.pinecone_client import PineconeClient

load_dotenv()
SECRET_KEY = os.getenv("SECRET_KEY", "change_this")
app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)

templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

# connect to DB
database.connect()
metadata.create_all(engine)

finops = FinOpsManager()
pine = PineconeClient()

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/signup", response_class=HTMLResponse)
def signup_get(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})

@app.post("/signup")
async def signup_post(request: Request, email: str = Form(...), password: str = Form(...), name: str = Form("")):
    try:
        await create_user(email, password, name)
    except Exception as e:
        return templates.TemplateResponse("signup.html", {"request": request, "error": str(e)})
    return RedirectResponse("/login", status_code=302)

@app.get("/login", response_class=HTMLResponse)
def login_get(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login_post(request: Request, email: str = Form(...), password: str = Form(...)):
    user = await verify_user(email, password)
    if not user:
        return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials"})
    request.session['user'] = dict(id=user["id"], email=user["email"], name=user["name"])
    return RedirectResponse("/dashboard", status_code=302)

@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=302)

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    user = request.session.get("user")
    if not user:
        return RedirectResponse("/login")
    # basic stats
    total_done = await database.fetch_val("SELECT COUNT(*) FROM results")
    cost_summary = finops.summary()
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "total_done": total_done, "cost_summary": cost_summary})

@app.get("/testimonials", response_class=HTMLResponse)
async def show_testimonials(request: Request):
    rows = await database.fetch_all(testimonials.select().order_by(testimonials.c.created_at.desc()).limit(20))
    return templates.TemplateResponse("testimonials.html", {"request": request, "items": rows})

@app.post("/submit_testimonial")
async def submit_testimonial(request: Request, name: str = Form(...), message: str = Form(...)):
    await database.execute(testimonials.insert().values(name=name, message=message))
    return RedirectResponse("/testimonials", status_code=302)

@app.post("/annotate", response_class=HTMLResponse)
async def annotate_endpoint(request: Request, file: bytes = None, batch_size: int = 100):
    user = request.session.get("user")
    if not user:
        return RedirectResponse("/login")
    # Expect raw text lines in uploaded file
    content = (file.decode("utf-8") if file else "")
    lines = [l.strip() for l in content.splitlines() if l.strip()]
    # start orchestrator (async)
    task = asyncio.create_task(orchestrate_dataset(lines, batch_size=batch_size, user_id=user["id"]))
    return templates.TemplateResponse("annotate_started.html", {"request": request, "count": len(lines)})

@app.on_event("shutdown")
def shutdown():
    database.disconnect()

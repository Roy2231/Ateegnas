from passlib.context import CryptContext
from backend.db import database, users
from sqlalchemy import select

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

async def create_user(email: str, password: str, name: str = ""):
    hashed = pwd_context.hash(password)
    query = users.insert().values(email=email, password_hash=hashed, name=name)
    await database.execute(query)

async def verify_user(email: str, password: str):
    query = users.select().where(users.c.email == email)
    row = await database.fetch_one(query)
    if not row:
        return None
    if not pwd_context.verify(password, row["password_hash"]):
        return None
    return row

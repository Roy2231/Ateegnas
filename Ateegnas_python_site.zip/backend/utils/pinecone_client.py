import os
try:
    import pinecone
except Exception:
    pinecone = None

class PineconeClient:
    def __init__(self):
        self.api_key = os.getenv('PINECONE_API_KEY')
        self.index_name = 'ateegnas'
        if pinecone and self.api_key:
            pinecone.init(api_key=self.api_key)
            if self.index_name not in pinecone.list_indexes():
                pinecone.create_index(self.index_name, dimension=1536)
            self.index = pinecone.Index(self.index_name)
        else:
            self.index = None

    def upsert(self, text, metadata):
        if not self.index:
            return False
        # compute embedding via OpenAI (placeholder) or local encoder then upsert
        # Here we simply upsert a dummy vector for scaffolding
        vec = [hash(text) % 1000 for _ in range(1536)]
        self.index.upsert([(text[:50], vec, metadata)])
        return True

    def query_similar(self, text, top_k=3):
        if not self.index:
            return []
        vec = [hash(text) % 1000 for _ in range(1536)]
        res = self.index.query(vec, top_k=top_k, include_metadata=True)
        return res

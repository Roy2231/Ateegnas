import time, json, os

class FinOpsManager:
    def __init__(self, logfile='finops_log.json'):
        self.model_latency = {'gpt-4o': 0.8, 'gpt-4o-mini': 0.15}
        self.model_cost = {'gpt-4o': 0.06, 'gpt-4o-mini': 0.01}
        self.logfile = logfile
        if not os.path.exists(self.logfile):
            open(self.logfile, 'w').close()

    def choose_model(self, complexity_score):
        # simple policy: use expensive model if complexity high
        if complexity_score > 0.7:
            return 'gpt-4o'
        return 'gpt-4o-mini'

    def log_cost(self, model, tokens):
        cost = self.model_cost.get(model, 0.02) * (tokens/1000.0)
        entry = {'time': time.time(), 'model': model, 'tokens': tokens, 'cost': cost}
        with open(self.logfile, 'a') as f:
            f.write(json.dumps(entry) + "\n")
        return cost

    def summary(self):
        # simple sum of costs in file
        total = 0.0
        try:
            with open(self.logfile, 'r') as f:
                for line in f:
                    if not line.strip(): continue
                    total += json.loads(line).get('cost',0)
        except FileNotFoundError:
            total = 0.0
        return f"${total:.4f} total spent (est.)"

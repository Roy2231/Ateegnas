import random

def compute_complexity(batch_texts):
    # naive complexity: average length normalized
    avg_len = sum(len(t.split()) for t in batch_texts)/max(1, len(batch_texts))
    score = min(1.0, avg_len / 300)
    return score

def choose_model_for_batch(batch_texts):
    score = compute_complexity(batch_texts)
    # simple rule-based
    if score > 0.8:
        return 'gpt-4o'
    if score > 0.4:
        return 'gpt-4o-mini'
    return 'gpt-4o-mini'  # default

def get_openai_model_name():
    # default getter - could be extended to rotate keys / models
    return 'gpt-4o-mini'

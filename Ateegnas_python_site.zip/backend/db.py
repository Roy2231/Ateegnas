from sqlalchemy import (Table, Column, Integer, String, MetaData, DateTime, Text, func)
from sqlalchemy import create_engine
from databases import Database
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ateegnas.db")
database = Database(DATABASE_URL)
metadata = MetaData()
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

users = Table(
    "users", metadata,
    Column("id", Integer, primary_key=True),
    Column("email", String, unique=True, nullable=False),
    Column("password_hash", String, nullable=False),
    Column("name", String, nullable=True),
    Column("created_at", DateTime, server_default=func.now())
)

results = Table(
    "results", metadata,
    Column("id", Integer, primary_key=True),
    Column("user_id", Integer),
    Column("text", Text),
    Column("label", Text),
    Column("model", String),
    Column("created_at", DateTime, server_default=func.now())
)

testimonials = Table(
    "testimonials", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String),
    Column("message", Text),
    Column("created_at", DateTime, server_default=func.now())
)

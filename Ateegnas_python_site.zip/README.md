# Ateegnas - Multi-Agent Annotation Platform (Python)

A prototype web application (FastAPI + Jinja2 templates) implementing:
- Multi-agent orchestration (Modal/async placeholders)
- RAG semantic caching (Pinecone integration placeholders)
- MCP/FinOps dynamic model switching (instrumentation included)
- Modal Labs task integration (placeholder)
- Signup/login, testimonials, dashboard and annotation flow

This is a developer scaffold. Add your API keys to `.env` before running.
